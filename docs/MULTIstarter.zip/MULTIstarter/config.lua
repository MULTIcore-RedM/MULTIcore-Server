-- ============================================================
-- MULTIstarter settings. One line of explanation per setting.
-- ============================================================
Config = {}

Config.Locale = ''                  -- language for this script ('de', 'fr' ...); empty = server-wide setr multicore_locale, else English
Config.NotifyDuration = 5000        -- how long notifications stay on screen (ms)

---------------------------------
-- the item
---------------------------------
Config.Item = 'starter_nugget'      -- item name (registered at start, no SQL needed)
Config.ItemWeight = 50              -- grams
Config.AdminGiveCommand = 'startergive' -- admins type /startergive to get 3 items for testing; false = no command

---------------------------------
-- the counter
---------------------------------
-- Example spot: the Valentine bank counter. Change it to your own place.
Config.Counter = vector3(-308.4189, 775.8842, 118.7017)
Config.Interact = 'auto'            -- 'auto' = MULTItarget when it runs (else hold-key prompt), 'target' = MULTItarget, 'prompt' = hold-key prompt
Config.PromptKey = 'J'              -- key name from MULTIcore's shared/keybinds.lua (prompt mode only)
Config.PromptDistance = 2.0         -- metres (prompt mode only)
Config.TargetIcon = 'fas fa-coins'  -- MULTItarget icon (target mode only)
Config.TargetRadius = 1.2           -- size of the MULTItarget sphere (target mode only)
Config.TargetDistance = 2.0         -- metres (target mode only)
Config.MaxUseDistance = 6.0         -- the server refuses a sale further than this from the counter (metres)

---------------------------------
-- prices (1899-level)
---------------------------------
Config.Price = 0.75                 -- dollars paid for one item
Config.MaxPerSale = 50              -- most items sold at once
Config.BonusJobs = { 'blacksmith' } -- these jobs get the bonus below
Config.JobBonus = 1.2               -- price multiplier for the jobs above (1.2 = 20% more)
Config.SaleCooldownMs = 2000        -- time between two sales by the same player (ms)
