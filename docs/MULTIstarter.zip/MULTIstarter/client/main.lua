-- ============================================================
-- MULTIstarter client: the counter (MULTItarget or prompt) and the sale box.
-- ============================================================

local zone = nil

local function notify(key, kind, ...)
    exports.MULTIcore:Notify({ text = _L(key, ...), title = _L('title'), type = kind or 'info', duration = Config.NotifyDuration })
end

local function openCounter()
    local have = MC.CountItem(Config.Item)
    if have < 1 then return notify('not_enough', 'error') end
    local input = lib.inputDialog(_L('title'), {
        { type = 'number', label = _L('how_many'), default = have, min = 1, max = math.min(have, Config.MaxPerSale) },
    })
    if input and input[1] then TriggerServerEvent('multistarter:server:sell', input[1]) end
end
RegisterNetEvent('multistarter:client:open', openCounter)

-- MULTItarget (Config.Interact 'auto' / 'target') or hold-key prompt, see @MULTIcore/lib/interact.lua
MCI.Run(Config.Interact, function(mode)
    if mode == 'target' then
        zone = MCI.AddZone({ coords = Config.Counter, radius = Config.TargetRadius, options = { {
            name = 'multistarter_counter', label = _L('prompt_sell'), icon = Config.TargetIcon,
            distance = Config.TargetDistance, onSelect = openCounter,
        } } })
    else
        MCI.AddPrompt('multistarter_counter', Config.Counter, Config.PromptKey, _L('prompt_sell'),
            { type = 'client', event = 'multistarter:client:open' }, Config.PromptDistance)
    end
end, function()
    if zone then MCI.RemoveZone(zone) zone = nil end
    MCI.RemovePrompt('multistarter_counter')
end)
