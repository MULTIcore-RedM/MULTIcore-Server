# MULTIstarter

A template for new MULTIcore scripts. Out of the box it is a small working script: players sell gold nuggets at a counter. Members of a bonus job get a better price, and admins can type `/startergive` to get test items.

## Start a new script
1. Copy this folder into your server's resources and rename it, for example `MULTIfishing`.
2. Search all files for `MULTIstarter` and `multistarter` and replace them with your name.
3. Change `config.lua`, the words in `locales/en.lua`, and the code in `client/main.lua` and `server/main.lua`.
4. Add `ensure MULTIfishing` to server.cfg after MULTIcore and MULTIinventory.

## What's inside
| File | What it shows |
|---|---|
| `fxmanifest.lua` | the four includes every MULTIcore script uses |
| `config.lua` | every setting commented, nothing hard-coded |
| `locales/*.lua` | 10 languages with the same keys; English is the master |
| `server/main.lua` | registering an item and a usable item, a safe sale (amount, cooldown, distance, item, job bonus, money), an admin command |
| `client/main.lua` | a MULTItarget counter with a hold-key prompt as fallback, and an ox_lib input box |
| `html/custom.css` | where a NUI page's own styles go |

Full API: `docs/API.md` in MULTIcore.
