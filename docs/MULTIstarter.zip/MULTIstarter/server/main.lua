-- ============================================================
-- MULTIstarter server. Everything that changes money or items is decided here,
-- never on the client.
-- ============================================================

local lastSale = {}

local function notify(src, key, kind, ...)
    exports.MULTIcore:Notify(src, { text = _L(key, ...), title = _L('title'), type = kind or 'info', duration = Config.NotifyDuration })
end

-- the item is added to the item list when the script starts
CreateThread(function()
    while GetResourceState('MULTIinventory') ~= 'started' or not exports.MULTIinventory:IsReady() do Wait(250) end
    MC.RegisterItem({ name = Config.Item, label = _L('item_label'), weight = Config.ItemWeight, description = _L('item_desc'), stack = true })
    MC.RegisterUsableItem(Config.Item, function(src)
        notify(src, 'inspect', 'info', ('%.2f'):format(Config.Price))
    end)
end)

RegisterNetEvent('multistarter:server:sell', function(amount)
    local src = source
    amount = math.floor(tonumber(amount) or 0)
    if amount < 1 or amount > Config.MaxPerSale then return notify(src, 'bad_amount', 'error', Config.MaxPerSale) end
    if not MC.IsLoggedIn(src) then return end

    local now = GetGameTimer()
    if lastSale[src] and now - lastSale[src] < Config.SaleCooldownMs then return notify(src, 'busy', 'error') end
    lastSale[src] = now

    local ped = GetPlayerPed(src)
    if ped == 0 or #(GetEntityCoords(ped) - Config.Counter) > Config.MaxUseDistance then return notify(src, 'too_far', 'error') end

    if not MC.TakeItem(src, Config.Item, amount) then return notify(src, 'not_enough', 'error') end
    local price = Config.Price * amount
    if MC.HasJob(src, Config.BonusJobs) then price = price * Config.JobBonus end
    price = math.floor(price * 100 + 0.5) / 100     -- keep cents
    MC.AddMoney(src, price, 'cash', 'multistarter sale')
    notify(src, 'sold', 'success', amount, ('%.2f'):format(price))
end)

AddEventHandler('playerDropped', function() lastSale[source] = nil end)

if Config.AdminGiveCommand then
    RegisterCommand(Config.AdminGiveCommand, function(src)
        if src == 0 or not MC.IsAdmin(src) then return end
        if MC.GiveItem(src, Config.Item, 3) then notify(src, 'given', 'success') else notify(src, 'no_room', 'error') end
    end, false)
end
