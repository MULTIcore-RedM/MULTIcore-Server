-- MULTIstarter: Deutsch
Locales = Locales or {}
Locales['de'] = {
    ['title'] = 'Prüfamt',
    ['item_label'] = 'Goldnugget',
    ['item_desc'] = 'Ein kleines Goldnugget. Das Prüfamt kauft diese.',
    ['prompt_sell'] = 'Nuggets verkaufen',
    ['how_many'] = 'Wie viele?',
    ['inspect'] = 'Ein schönes Nugget. Das Prüfamt zahlt je $%s.',
    ['bad_amount'] = 'Du kannst zwischen 1 und %s auf einmal verkaufen.',
    ['busy'] = 'Langsam, der Angestellte wiegt noch.',
    ['too_far'] = 'Du bist zu weit vom Schalter entfernt.',
    ['not_enough'] = 'So viele Nuggets hast du nicht.',
    ['sold'] = '%s Nuggets für $%s verkauft.',
    ['given'] = 'Du hast 3 Nuggets bekommen.',
    ['no_room'] = 'Kein Platz in deiner Tasche.',
}
