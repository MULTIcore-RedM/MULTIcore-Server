-- MULTIstarter: Español
Locales = Locales or {}
Locales['es'] = {
    ['title'] = 'Oficina de ensayo',
    ['item_label'] = 'Pepita de oro',
    ['item_desc'] = 'Una pequeña pepita de oro. La oficina de ensayo las compra.',
    ['prompt_sell'] = 'Vender pepitas',
    ['how_many'] = '¿Cuántas?',
    ['inspect'] = 'Una buena pepita. La oficina de ensayo paga $%s cada una.',
    ['bad_amount'] = 'Puedes vender entre 1 y %s a la vez.',
    ['busy'] = 'Despacio, el empleado sigue pesando.',
    ['too_far'] = 'Estás demasiado lejos del mostrador.',
    ['not_enough'] = 'No tienes tantas pepitas.',
    ['sold'] = 'Vendiste %s pepitas por $%s.',
    ['given'] = 'Recibiste 3 pepitas.',
    ['no_room'] = 'No hay sitio en tu morral.',
}
