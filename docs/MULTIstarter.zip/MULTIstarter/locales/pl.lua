-- MULTIstarter: Polski
Locales = Locales or {}
Locales['pl'] = {
    ['title'] = 'Biuro probiercze',
    ['item_label'] = 'Samorodek złota',
    ['item_desc'] = 'Mały samorodek złota. Biuro probiercze je skupuje.',
    ['prompt_sell'] = 'Sprzedaj samorodki',
    ['how_many'] = 'Ile?',
    ['inspect'] = 'Ładny samorodek. Biuro probiercze płaci $%s za sztukę.',
    ['bad_amount'] = 'Możesz sprzedać od 1 do %s naraz.',
    ['busy'] = 'Powoli, urzędnik jeszcze waży.',
    ['too_far'] = 'Jesteś za daleko od lady.',
    ['not_enough'] = 'Nie masz tylu samorodków.',
    ['sold'] = 'Sprzedano %s samorodków za $%s.',
    ['given'] = 'Otrzymałeś 3 samorodki.',
    ['no_room'] = 'Brak miejsca w torbie.',
}
