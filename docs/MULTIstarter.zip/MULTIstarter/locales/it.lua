-- MULTIstarter: Italiano
Locales = Locales or {}
Locales['it'] = {
    ['title'] = 'Ufficio del saggio',
    ['item_label'] = 'Pepita d\'oro',
    ['item_desc'] = 'Una piccola pepita d\'oro. L\'ufficio del saggio le compra.',
    ['prompt_sell'] = 'Vendi pepite',
    ['how_many'] = 'Quante?',
    ['inspect'] = 'Una bella pepita. L\'ufficio del saggio paga $%s l\'una.',
    ['bad_amount'] = 'Puoi venderne da 1 a %s alla volta.',
    ['busy'] = 'Piano, l\'impiegato sta ancora pesando.',
    ['too_far'] = 'Sei troppo lontano dal bancone.',
    ['not_enough'] = 'Non hai così tante pepite.',
    ['sold'] = 'Vendute %s pepite per $%s.',
    ['given'] = 'Hai ricevuto 3 pepite.',
    ['no_room'] = 'Non c\'è spazio nella borsa.',
}
