-- MULTIstarter: Português (Brasil)
Locales = Locales or {}
Locales['pt-br'] = {
    ['title'] = 'Escritório de ensaio',
    ['item_label'] = 'Pepita de ouro',
    ['item_desc'] = 'Uma pequena pepita de ouro. O escritório de ensaio compra.',
    ['prompt_sell'] = 'Vender pepitas',
    ['how_many'] = 'Quantas?',
    ['inspect'] = 'Uma bela pepita. O escritório de ensaio paga $%s cada.',
    ['bad_amount'] = 'Você pode vender entre 1 e %s de uma vez.',
    ['busy'] = 'Calma, o atendente ainda está pesando.',
    ['too_far'] = 'Você está longe demais do balcão.',
    ['not_enough'] = 'Você não tem tantas pepitas.',
    ['sold'] = 'Vendeu %s pepitas por $%s.',
    ['given'] = 'Você recebeu 3 pepitas.',
    ['no_room'] = 'Sem espaço na sua bolsa.',
}
