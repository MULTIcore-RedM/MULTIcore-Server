-- MULTIstarter: Türkçe
Locales = Locales or {}
Locales['tr'] = {
    ['title'] = 'Ayar Bürosu',
    ['item_label'] = 'Altın Külçe',
    ['item_desc'] = 'Küçük bir altın külçe. Ayar bürosu bunları satın alır.',
    ['prompt_sell'] = 'Külçe sat',
    ['how_many'] = 'Kaç tane?',
    ['inspect'] = 'Güzel bir külçe. Ayar bürosu tanesine $%s öder.',
    ['bad_amount'] = 'Bir seferde 1 ile %s arası satabilirsin.',
    ['busy'] = 'Yavaş, memur hâlâ tartıyor.',
    ['too_far'] = 'Tezgâha çok uzaksın.',
    ['not_enough'] = 'O kadar külçen yok.',
    ['sold'] = '%s külçe $%s karşılığında satıldı.',
    ['given'] = '3 külçe aldın.',
    ['no_room'] = 'Çantanda yer yok.',
}
