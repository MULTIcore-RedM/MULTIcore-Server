-- MULTIstarter: Français
Locales = Locales or {}
Locales['fr'] = {
    ['title'] = 'Bureau d\'essai',
    ['item_label'] = 'Pépite d\'or',
    ['item_desc'] = 'Une petite pépite d\'or. Le bureau d\'essai les achète.',
    ['prompt_sell'] = 'Vendre des pépites',
    ['how_many'] = 'Combien ?',
    ['inspect'] = 'Une belle pépite. Le bureau d\'essai paie $%s pièce.',
    ['bad_amount'] = 'Vous pouvez en vendre entre 1 et %s à la fois.',
    ['busy'] = 'Doucement, le commis pèse encore.',
    ['too_far'] = 'Vous êtes trop loin du comptoir.',
    ['not_enough'] = 'Vous n\'avez pas autant de pépites.',
    ['sold'] = '%s pépites vendues pour $%s.',
    ['given'] = 'Vous avez reçu 3 pépites.',
    ['no_room'] = 'Plus de place dans votre sacoche.',
}
