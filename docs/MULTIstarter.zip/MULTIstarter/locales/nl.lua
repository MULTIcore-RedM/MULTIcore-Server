-- MULTIstarter: Nederlands
Locales = Locales or {}
Locales['nl'] = {
    ['title'] = 'Keurkantoor',
    ['item_label'] = 'Goudklompje',
    ['item_desc'] = 'Een klein goudklompje. Het keurkantoor koopt ze.',
    ['prompt_sell'] = 'Klompjes verkopen',
    ['how_many'] = 'Hoeveel?',
    ['inspect'] = 'Een mooi klompje. Het keurkantoor betaalt $%s per stuk.',
    ['bad_amount'] = 'Je kunt tussen 1 en %s tegelijk verkopen.',
    ['busy'] = 'Rustig, de klerk is nog aan het wegen.',
    ['too_far'] = 'Je bent te ver van de toonbank.',
    ['not_enough'] = 'Zoveel klompjes heb je niet.',
    ['sold'] = '%s klompjes verkocht voor $%s.',
    ['given'] = 'Je hebt 3 klompjes gekregen.',
    ['no_room'] = 'Geen ruimte in je tas.',
}
