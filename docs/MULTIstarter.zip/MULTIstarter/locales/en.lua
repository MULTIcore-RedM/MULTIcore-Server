-- MULTIstarter: English (master file, every key lives here first)
Locales = Locales or {}
Locales['en'] = {
    ['title'] = 'Assay Office',
    ['item_label'] = 'Gold Nugget',
    ['item_desc'] = 'A small nugget of gold. The assay office buys these.',
    ['prompt_sell'] = 'Sell nuggets',
    ['how_many'] = 'How many?',
    ['inspect'] = 'A fine nugget. The assay office pays $%s each.',
    ['bad_amount'] = 'You can sell between 1 and %s at once.',
    ['busy'] = 'Slow down, the clerk is still weighing.',
    ['too_far'] = 'You are too far from the counter.',
    ['not_enough'] = 'You do not have that many nuggets.',
    ['sold'] = 'Sold %s nuggets for $%s.',
    ['given'] = 'You got 3 nuggets.',
    ['no_room'] = 'No room in your satchel.',
}
