-- MULTIstarter: copy this folder to start a new MULTIcore script.
-- Rename the folder, then search for "MULTIstarter" / "multistarter" and replace it with your script's name.
fx_version 'cerulean'
game 'rdr3'
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'
lua54 'yes'

name 'MULTIstarter'
author 'Your name'
description 'Starter template for MULTIcore scripts: sell an item at a counter.'
version '0.1.0'

shared_scripts {
    '@ox_lib/init.lua',
    '@MULTIcore/lib/api.lua',      -- MC.GetCharacter, MC.AddMoney, MC.GiveItem ... (docs/API.md)
    '@MULTIcore/shared/i18n.lua',  -- _L('key') reads locales/<language>.lua
    'config.lua',
    'locales/*.lua',
}

client_scripts {
    '@MULTIcore/lib/ui.lua',       -- ox_lib menus and dialogs in the MULTI look
    '@MULTIcore/lib/interact.lua', -- MULTItarget, with hold-key prompts as fallback
    'client/main.lua',
}

server_scripts {
    'server/main.lua',
}

dependencies {
    'MULTIcore',
    'MULTItarget',   -- MULTIcore's target system (every MULTI script needs it)
    'MULTIinventory',
    'ox_lib',
}
