// MULTIexample page. Messages from client/main.lua:
//   { action: 'open', text, lang, cash, tabs: [ { id, label } ], items: [ { name, label, desc, price, tab } ] }
//   { action: 'close' }
// Calls back with fetch('https://<resource>/<name>'): 'buy' { name, amount, note } and 'close'.
// Opened in a normal browser (no game), it fills itself with test data so you can look at it.
(function () {
    'use strict';
    var app = document.getElementById('app');
    var text = {}, items = [], tabs = [], tab = null, sel = 0;
    var $ = function (id) { return document.getElementById(id); };

    function post(name, body) {
        if (typeof GetParentResourceName !== 'function') return;
        fetch('https://' + GetParentResourceName() + '/' + name, { method: 'POST', body: JSON.stringify(body || {}) }).catch(function () {});
    }
    function L(key) { return text[key] || key; }
    // dollars with small cents, like the game: $12.50
    function money(el, v) {
        var n = Number(v) || 0;
        var d = Math.floor(n), c = Math.round((n - d) * 100);
        el.innerHTML = '';
        el.appendChild(document.createTextNode('$' + d));
        var s = document.createElement('span');
        s.className = 'mc-cents';
        s.textContent = (c < 10 ? '0' : '') + c;
        el.appendChild(s);
    }

    function shown() { return items.filter(function (it) { return !tab || it.tab === tab; }); }

    function render() {
        // words
        document.querySelectorAll('[data-l]').forEach(function (el) { el.textContent = L(el.getAttribute('data-l')); });
        // tabs
        var t = $('tabs'); t.innerHTML = '';
        tabs.forEach(function (x) {
            var b = document.createElement('div');
            b.className = 'mc-tab' + (x.id === tab ? ' active' : '');
            b.textContent = x.label;
            b.addEventListener('click', function () { tab = x.id; sel = 0; render(); });
            t.appendChild(b);
        });
        // rows (textContent only: never put player text into innerHTML)
        var list = $('list'); list.innerHTML = '';
        shown().forEach(function (it, i) {
            var r = document.createElement('div');
            r.className = 'mc-row mx-row' + (i === sel ? ' active' : '');
            var name = document.createElement('span'); name.textContent = it.label;
            var price = document.createElement('span'); price.className = 'mc-money'; money(price, it.price);
            r.appendChild(name); r.appendChild(price);
            r.addEventListener('click', function () { sel = i; render(); });
            list.appendChild(r);
        });
        detail();
    }

    function detail() {
        var it = shown()[sel];
        $('dName').textContent = it ? it.label : '';
        $('dDesc').textContent = it ? it.desc : '';
        var n = Number($('amount').value) || 1;
        $('amountVal').textContent = n;
        money($('total'), it ? it.price * n : 0);
    }

    $('amount').addEventListener('input', detail);
    $('go').addEventListener('click', function () {
        var it = shown()[sel];
        if (it) post('buy', { name: it.name, amount: Number($('amount').value) || 1, note: $('note').value });
    });
    $('close').addEventListener('click', function () { post('close'); });
    window.addEventListener('keydown', function (e) {
        if (app.classList.contains('mc-hidden')) return;
        if (e.key === 'Escape') post('close');
        else if (e.key === 'ArrowDown') { sel = Math.min(shown().length - 1, sel + 1); render(); }
        else if (e.key === 'ArrowUp') { sel = Math.max(0, sel - 1); render(); }
        else if (e.key === 'Enter' && document.activeElement.tagName !== 'INPUT') $('go').click();
    });

    window.addEventListener('message', function (e) {
        var m = e.data || {};
        if (m.action === 'open') {
            text = m.text || {}; items = m.items || []; tabs = m.tabs || [];
            tab = tabs[0] ? tabs[0].id : null; sel = 0;
            app.classList.toggle('mc-cyrillic', m.lang === 'ru');
            money($('cash'), m.cash);
            app.classList.remove('mc-hidden');
            render();
        } else if (m.action === 'close') {
            app.classList.add('mc-hidden');
        }
    });

    // preview in a normal browser
    if (typeof GetParentResourceName !== 'function') {
        document.body.style.background = 'linear-gradient(160deg, #8a9a72, #4d5a3c 60%, #2c3324)';
        window.postMessage({
            action: 'open', lang: 'en', cash: 42.75,
            text: { ui_subtitle: 'Valentine', ui_title: 'General Store', ui_cash: 'Cash', ui_note: 'Note', ui_amount: 'Amount', ui_total: 'Total', ui_buy: 'Buy', ui_close: 'Close', ui_select: 'Select' },
            tabs: [{ id: 'food', label: 'Food' }, { id: 'tools', label: 'Tools' }],
            items: [
                { name: 'bread', label: 'Bread', desc: 'A fresh loaf.', price: 0.10, tab: 'food' },
                { name: 'canned_beans', label: 'Canned Beans', desc: 'Keeps for months.', price: 0.15, tab: 'food' },
                { name: 'coffee', label: 'Coffee', desc: 'A tin of ground coffee.', price: 0.25, tab: 'food' },
                { name: 'lantern', label: 'Lantern', desc: 'Oil lantern.', price: 1.50, tab: 'tools' }
            ]
        }, '*');
    }
})();
